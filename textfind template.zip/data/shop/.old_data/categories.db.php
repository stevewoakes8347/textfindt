id;nazwa;root;priority;szablon;seo;template;xtr1;xtr2;xtr3;
1;Main Category;0;;0;;;;;;