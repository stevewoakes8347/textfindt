id;nazwa;kategoria;autor;opis1;opis2;index;stron;cena1;cena2;zdjecie;promocja;pokaz;optionsID;manufacturer;priority;seo;template;weight;productCode;freeShip;downloadable;ImgDisplay;attachment;xtr2;
1;My first product #1;:1:;;;;;;5;;||||||||||||||;;0;;;3;^|^|^|;;1|0|1|;;;;||;|*^*|*^*|*^*|*^*|*^*;;
2;My first product #2;:1:;;;;;;10;;||||||||||||||;;0;;;2;^|^|^|;;1|0|1|;;;;||;|*^*|*^*|*^*|*^*|*^*;;
3;My first product #3;:1:;;;;;;15;;||||||||||||||;;0;;;1;^|^|^|;;1|0|1|;;;;||;|*^*|*^*|*^*|*^*|*^*;;