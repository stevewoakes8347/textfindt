id;name;time;price;pricePerWeight;desc;
1;Default Delivery;3 days;10;;Default Delivery;