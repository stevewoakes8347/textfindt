id;value;xtr1;xtr2;xtr3;
1;This is sample product, you can buy it now;;;;
2;This is sample product, you can buy it now;;;;
3;This is sample product, you can buy it now;;;;