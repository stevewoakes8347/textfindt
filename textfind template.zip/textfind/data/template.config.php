<?php $TemplateConfig = array (
  'htmlClass' => 'ko_Theme',
  'gFont1' => 'Chivo',
  'gFont2' => 'Roboto',
  'fontStyle' => '.ko_Theme #website, .ko_Theme #website p{font-family:var(--font2),sans-serif;}.ko_Theme #website a.btn, .ko_Theme #website button.btn{font-family:var(--font1),sans-serif;}.ko_Theme #website h1,.ko_Theme #website h2,.ko_Theme #website h3{font-family:var(--font1),sans-serif;font-weight:700}.ko_Theme #website h4,.ko_Theme #website h5,.ko_Theme #website h6{font-family:var(--font1),sans-serif;font-weight:700}.ko_Theme #website .topmenu{font-family:var(--font2),sans-serif;font-weight:400}.ko_Theme #website .logoHolder h2{font-family:var(--font1),sans-serif;font-weight:700}.ko_Theme #website #footerContent {font-family:var(--font2),sans-serif;}.ko_Theme #website #footerContent h1,.ko_Theme #website #footerContent h2,.ko_Theme #website #footerContent h3,.ko_Theme #website #footerContent h4,.ko_Theme #website #footerContent h5,.ko_Theme #website #footerContent h6 {font-family:var(--font2),sans-serif;}',
  'fontStyleData' => '{\\"title\\":{\\"v\\":\\"1\\"},\\"titleWeight\\":{\\"v\\":\\"700\\"},\\"menu\\":{\\"v\\":\\"2\\"},\\"menuWeight\\":{\\"v\\":\\"400\\"},\\"headers1\\":{\\"v\\":\\"1\\"},\\"headers1Weight\\":{\\"v\\":\\"700\\"},\\"headers2\\":{\\"v\\":\\"1\\"},\\"headers2Weight\\":{\\"v\\":\\"700\\"},\\"button\\":{\\"v\\":\\"1\\"},\\"text\\":{\\"v\\":\\"2\\"},\\"footerTitle\\":{\\"v\\":\\"2\\"},\\"footerText\\":{\\"v\\":\\"2\\"}}',
  'kopageScrollToTop' => '1',
  'kopageOnScrollAnimations' => '1',
  'menuStyleData' => '{\\"titleColor\\":{\\"v\\":\\"--color1_150\\"},\\"titleSize\\":{\\"v\\":\\"24\\"},\\"logoPadding\\":{\\"v\\":\\"0\\"},\\"logoPadding_1\\":{\\"v\\":\\"60\\"},\\"logoPadding_2\\":{\\"v\\":\\"20\\"},\\"logoPadding_3\\":{\\"v\\":\\"0\\"},\\"logoPadding_4\\":{\\"v\\":\\"0\\"},\\"logoSize\\":{\\"v\\":\\"40\\"},\\"logoBlock\\":{\\"t\\":\\"c\\"},\\"menuType_1\\":{\\"t\\":\\"r\\"},\\"menuType_2\\":{\\"t\\":\\"r\\",\\"v\\":\\"2\\"},\\"ExtraSpace\\":{\\"v\\":\\"100\\"},\\"menuType_5\\":{\\"t\\":\\"r\\"},\\"menuType_3\\":{\\"t\\":\\"r\\"},\\"color\\":{\\"v\\":\\"\\"},\\"radius\\":{\\"v\\":\\"0\\"},\\"padding\\":{\\"v\\":\\"20\\"},\\"padding_1\\":{\\"v\\":\\"50\\"},\\"padding_2\\":{\\"v\\":\\"50\\"},\\"padding_3\\":{\\"v\\":\\"20\\"},\\"padding_4\\":{\\"v\\":\\"20\\"},\\"margin\\":{\\"v\\":\\"0\\"},\\"margin_1\\":{\\"v\\":\\"50\\"},\\"margin_2\\":{\\"v\\":\\"20\\"},\\"margin_3\\":{\\"v\\":\\"0\\"},\\"margin_4\\":{\\"v\\":\\"20\\"},\\"border\\":{\\"v\\":\\"!\\"},\\"border_1\\":{\\"v\\":\\"0\\"},\\"border_2\\":{\\"v\\":\\"0\\"},\\"border_3\\":{\\"v\\":\\"0\\"},\\"border_4\\":{\\"v\\":\\"0\\"},\\"borderColor\\":{\\"v\\":\\"--color2\\"},\\"shadow\\":{\\"t\\":\\"c\\"},\\"fixed\\":{\\"t\\":\\"c\\"},\\"hamburger\\":{\\"t\\":\\"c\\"},\\"itemColor\\":{\\"v\\":\\"rgb(42, 42, 42)\\"},\\"itemSize\\":{\\"v\\":\\"17\\"},\\"itemBgColor\\":{\\"v\\":\\"\\"},\\"itemRadius\\":{\\"v\\":\\"0\\"},\\"itemPadding\\":{\\"v\\":\\"!\\"},\\"itemPadding_1\\":{\\"v\\":\\"5\\"},\\"itemPadding_2\\":{\\"v\\":\\"0\\"},\\"itemPadding_3\\":{\\"v\\":\\"5\\"},\\"itemPadding_4\\":{\\"v\\":\\"0\\"},\\"itemSpacing\\":{\\"v\\":\\"!\\"},\\"itemSpacing_1\\":{\\"v\\":\\"0\\"},\\"itemSpacing_2\\":{\\"v\\":\\"0\\"},\\"itemSpacing_3\\":{\\"v\\":\\"0\\"},\\"itemSpacing_4\\":{\\"v\\":\\"20\\"},\\"itemBorder\\":{\\"v\\":\\"0\\"},\\"itemBorder_1\\":{\\"v\\":\\"0\\"},\\"itemBorder_2\\":{\\"v\\":\\"0\\"},\\"itemBorder_3\\":{\\"v\\":\\"2\\"},\\"itemBorder_4\\":{\\"v\\":\\"0\\"},\\"itemBorderColor\\":{\\"v\\":\\"transparent\\"},\\"itemShadow\\":{\\"t\\":\\"c\\"},\\"itemCapital\\":{\\"t\\":\\"c\\"},\\"itemTransition\\":{\\"t\\":\\"c\\",\\"v\\":\\"1\\"},\\"itemColor_hover\\":{\\"v\\":\\"--color2\\"},\\"itemBgColor_hover\\":{\\"v\\":\\"\\"},\\"itemBorderColor_hover\\":{\\"v\\":\\"--color2\\"},\\"accitemColor\\":{\\"v\\":\\"--color2\\"},\\"accitemSize\\":{\\"v\\":\\"17\\"},\\"accitemBgColor\\":{\\"v\\":\\"\\"},\\"accitemRadius\\":{\\"v\\":\\"50\\"},\\"accitemPadding\\":{\\"v\\":\\"!\\"},\\"accitemPadding_1\\":{\\"v\\":\\"15\\"},\\"accitemPadding_2\\":{\\"v\\":\\"17\\"},\\"accitemPadding_3\\":{\\"v\\":\\"15\\"},\\"accitemPadding_4\\":{\\"v\\":\\"17\\"},\\"accitemSpacing\\":{\\"v\\":\\"!\\"},\\"accitemSpacing_1\\":{\\"v\\":\\"0\\"},\\"accitemSpacing_2\\":{\\"v\\":\\"0\\"},\\"accitemSpacing_3\\":{\\"v\\":\\"0\\"},\\"accitemSpacing_4\\":{\\"v\\":\\"40\\"},\\"accitemBorder\\":{\\"v\\":\\"2\\"},\\"accitemBorder_1\\":{\\"v\\":\\"\\"},\\"accitemBorder_2\\":{\\"v\\":\\"\\"},\\"accitemBorder_3\\":{\\"v\\":\\"\\"},\\"accitemBorder_4\\":{\\"v\\":\\"\\"},\\"accitemBorderColor\\":{\\"v\\":\\"--color2\\"},\\"accitemColor_hover\\":{\\"v\\":\\"rgb(255, 255, 255)\\"},\\"accitemBgColor_hover\\":{\\"v\\":\\"--color2\\"},\\"accitemBorderColor_hover\\":{\\"v\\":\\"\\"},\\"acc2itemColor\\":{\\"v\\":\\"rgb(255, 255, 255)\\"},\\"acc2itemSize\\":{\\"v\\":\\"17\\"},\\"acc2itemBgColor\\":{\\"v\\":\\"--color1\\"},\\"acc2itemRadius\\":{\\"v\\":\\"50\\"},\\"acc2itemPadding\\":{\\"v\\":\\"17\\"},\\"acc2itemPadding_1\\":{\\"v\\":\\"\\"},\\"acc2itemPadding_2\\":{\\"v\\":\\"\\"},\\"acc2itemPadding_3\\":{\\"v\\":\\"\\"},\\"acc2itemPadding_4\\":{\\"v\\":\\"\\"},\\"acc2itemSpacing\\":{\\"v\\":\\"!\\"},\\"acc2itemSpacing_1\\":{\\"v\\":\\"0\\"},\\"acc2itemSpacing_2\\":{\\"v\\":\\"0\\"},\\"acc2itemSpacing_3\\":{\\"v\\":\\"0\\"},\\"acc2itemSpacing_4\\":{\\"v\\":\\"5\\"},\\"acc2itemBorder\\":{\\"v\\":\\"0\\"},\\"acc2itemBorder_1\\":{\\"v\\":\\"\\"},\\"acc2itemBorder_2\\":{\\"v\\":\\"\\"},\\"acc2itemBorder_3\\":{\\"v\\":\\"\\"},\\"acc2itemBorder_4\\":{\\"v\\":\\"\\"},\\"acc2itemBorderColor\\":{\\"v\\":\\"rgb(255, 255, 255)\\"},\\"acc2itemColor_hover\\":{\\"v\\":\\"rgb(255, 255, 255)\\"},\\"acc2itemBgColor_hover\\":{\\"v\\":\\"--color1_175\\"},\\"acc2itemBorderColor_hover\\":{\\"v\\":\\"\\"},\\"customCSS\\":{\\"v\\":\\"\\"}}',
  'menuStyle' => '.ko_Theme #headerContent:not(.koZeroPadding),.ko_Theme #subpageHeaderContent:not(.koZeroPadding){}.ko_Theme #headerMenu{/*overflow:auto;*//*display:flex;flex-direction: row;justify-content: space-between;align-items: center;*/padding:20px;margin:0px;border:0px solid var(--color2);border-width:0px 0px 0px 0px;border-radius:0px;position:absolute;display:block;position:absolute;z-index:3;;}.ko_Theme .logoHolder{padding:0px;;white-space: nowrap;}.ko_Theme .logoHolder h2{font-size:24px;color:var(--color1_150);display: flex;align-items: center;min-height:40px;}@media (max-width: 768px){.ko_Theme .logoHolder h2{font-size:22px;}}.ko_Theme .logoHolder img{max-height:40px;height:40px;min-height:40px;}.ko_Theme .menuHolder { display: flex;}.ko_Theme .menuHolder li{}.ko_Theme .menuHolder li a{font-size:17px;color:rgb(42, 42, 42);padding:5px 0px 5px 0px;margin:0px 0px 0px 20px;border-radius:0px;border:0px solid transparent;transition:0.2s all;}.ko_Theme .menuHolder li.active a,.ko_Theme .menuHolder li a:hover{color:var(--color2);border-color:var(--color2);}.ko_Theme .menuHolder li.accent1 a,.ko_Theme .menuHolder li.accent1.active a{font-size:17px;color:var(--color2);padding:15px 17px 15px 17px;margin:0px 0px 0px 40px;border-radius:50px;border:2px solid var(--color2);}.ko_Theme .menuHolder li.accent1.active a,.ko_Theme .menuHolder li.accent1 a:hover{color:rgb(255, 255, 255);background:var(--color2);}.ko_Theme .menuHolder li.accent2 a,.ko_Theme .menuHolder li.accent2.active a{font-size:17px;color:rgb(255, 255, 255);background:var(--color1);padding:17px;margin:0px 0px 0px 5px;border-radius:50px;border:0px solid rgb(255, 255, 255);}.ko_Theme .menuHolder li.accent2.active a,.ko_Theme .menuHolder li.accent2 a:hover{color:rgb(255, 255, 255);background:var(--color1_175);}.ko_Theme .menuHolder li.topmenuSocial a{color:var(--color1_150)}#contentArea:not(.lpMode) #contentAreaElement + .kedit::before{content:\\"\\";white-space:nowrap;display:block;padding-top:100px;}#contentArea:not(.lpMode) #contentAreaElement + .kedit .k_Edit,#contentArea:not(.lpMode) #contentAreaElement + .kedit .kopageInModuleMenu{top:100px;border-top-right-radius: 4px;}#contentArea:not(.lpMode) #contentAreaElement + .kedit span.k_EditMore{border-radius: 0 4px 4px 0;}.keditColumn .k_Edit,.keditColumn .kopageInModuleMenu{top:2px!important}',
  'color1' => '#313D5C',
  'color2' => '#EE626B',
  'colorStyleShades' => '--color1_rgb: 49,61,92;--color1_hsl: 223,30%,28%;--color1_hs: 223,30%;--color1_h: 223;--color1_s: 30%;--color1_l: 28%;--color1_25:#cccfd6;--color1_50:#989eae;--color1_75:#656e85;--color1_125:#252e45;--color1_150:#191f2e;--color1_175:#0c0f17;--color2_rgb: 238,98,107;--color2_hsl: 356,80%,66%;--color2_hs: 356,80%;--color2_h: 356;--color2_s: 80%;--color2_l: 66%;--color2_25:#fbd8da;--color2_50:#f7b1b5;--color2_75:#f28990;--color2_125:#b34a50;--color2_150:#773136;--color2_175:#3c191b;--color1_bw:rgba(255,255,255,0.8);--color1_25_bw:rgba(0,0,0,0.8);--color1_50_bw:rgba(255,255,255,0.8);--color1_75_bw:rgba(255,255,255,0.8);--color1_125_bw:rgba(255,255,255,0.8);--color1_150_bw:rgba(255,255,255,0.8);--color1_175_bw:rgba(255,255,255,0.8);--color2_bw:rgba(255,255,255,0.8);--color2_25_bw:rgba(0,0,0,0.8);--color2_50_bw:rgba(0,0,0,0.8);--color2_75_bw:rgba(255,255,255,0.8);--color2_125_bw:rgba(255,255,255,0.8);--color2_150_bw:rgba(255,255,255,0.8);--color2_175_bw:rgba(255,255,255,0.8);',
  'colorStyle' => '#contentArea .koColor {color:#313D5C;}ul.koCheckList li:before {background:#313D5C;}.ko_Theme #website .btn-primary {background-color:var(--color1);border-color:var(--color1);}.ko_Theme #website .btn-outline-primary {color:var(--color1);border-color:var(--color1);}.ko_Theme #website .btn-outline-primary:hover {background-color:var(--color1);color:var(--color1_bw);border-color:var(--color1);}#website .page-item.active .page-link {background-color:#313D5C;color:var(--color1_bw);border-color:var(--color1);}#contentArea a:not(.btn),#contentArea a.btn-link {color:var(--color1)}#website.kopageMenu a:not(.btn):not(.kopageMenuButton),#website.kopageMenu a.btn-link {color:var(--color1)}.ko_Theme #contentArea, .ko_Theme .koThemeDark #contentArea .whiteShadowContainer {color:rgba(0, 0, 0, .5)}#contentArea h1, #contentArea h2, #contentArea h3,#contentArea h1 a, #contentArea h2 a, #contentArea h3 a, .koThemeDark #contentArea .whiteShadowContainer strong, .koThemeDark #contentArea .whiteShadowContainer h1, .koThemeDark #contentArea .whiteShadowContainer h2, .koThemeDark #contentArea .whiteShadowContainer h3{color: var(--color1_125);}#contentArea h4, #contentArea h5, #contentArea h6,#contentArea h4 a, #contentArea h5 a, #contentArea h6 a, .koThemeDark #contentArea .whiteShadowContainer strong, .koThemeDark #contentArea .whiteShadowContainer h4, .koThemeDark #contentArea .whiteShadowContainer h5, .koThemeDark #contentArea .whiteShadowContainer h6 {color: var(--color1_125);}.ko_Theme #website #footerContent {color: #000000;}.ko_Theme #website #footerContent h1,.ko_Theme #website #footerContent h2,.ko_Theme #website #footerContent h3,.ko_Theme #website #footerContent h4,.ko_Theme #website #footerContent h5,.ko_Theme #website #footerContent h6 {color: rgb(0, 0, 0);}',
  'colorStyleData' => '{\\"text\\":{\\"v\\":\\"rgba(0, 0, 0, .5)\\"},\\"headers1\\":{\\"v\\":\\"--color1_125\\"},\\"headers2\\":{\\"v\\":\\"--color1_125\\"},\\"button\\":{\\"v\\":\\"--color1\\"},\\"footerTitle\\":{\\"v\\":\\"rgb(0, 0, 0)\\"},\\"footerText\\":{\\"v\\":\\"#000000\\"},\\"Color1\\":{\\"v\\":\\"#313D5C\\"},\\"Color2\\":{\\"v\\":\\"#EE626B\\"}}',
  'SlidesHeight' => '',
  'Scroll' => '',
  'footer' => '<section data-pcid="5500.4" id="kedit_tj0penx0h" class="kedit keditFooter1 p-0">


    <div class="container text-center">

        <div class="p-0 kedit" id="kpg_5182821">

            <div class="koSeparator koSeparatorBlock koSeparatorCenter" data-bg="rgb(222, 222, 222)" data-aos="fade-in" style="background: rgb(222, 222, 222) none repeat scroll 0% 0%; width: 100%; height: 2px; margin-top: 10px; margin-bottom: 10px;" data-width="100"></div>

            <div class="py-4">
                <img class="keditFooterLogo lazy" alt="Company Name" title="" data-src="data/files/theme/logo-success-white.svg">
            </div>

            <div class="keditable mb-4 keditFooterCompany"><!--StartFragment-->Disclaimer: You may not use our service or the information it provides to make any choices about consumer credit, any employment, insurance, rental tenant screening, or any other purposes that does require FCRA compliance<!--EndFragment--></div>

        </div>

        <div class="p-0 kedit keditFooterApp" id="kpg_6976752">
            {%footer%}
        </div>

        <div class="kedit p-0" id="kpg_6228653">

            <div class="my-4 keditable">

                <a href="#">Privacy Policy</a>
                &nbsp;&nbsp;&nbsp; <a href="#">Terms</a> &nbsp;&nbsp;&nbsp;
                <a href="#">Contact Us</a>

            </div>

            <div class="my-4 keditable keditFooterCopyright" style="font-size: 14px;">Copyright ©2022 All rights reserved.</div>

        </div>

    </div>



</section>',
  'gFont1_apply' => '#website h1,#website h2,#website #content h3,#website .topmenu',
  'gFont2_apply' => '#website,#website p',
  'gFontPair' => 'custom',
  'kopageBodyBoxed' => '0',
  'customCode' => '<style>

    .ko_ThemeBoxed #website
    {margin-top:0;margin-bottom:0;box-shadow:none}

</style>',
  'menuStyleType' => '2',
  'menuStyleMobile' => '',
  '_theme' => 
  array (
    'logo' => 'logo-success.svg',
    'logotitle' => 0,
  ),
);