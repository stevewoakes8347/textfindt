<?php

define("_START_ID","1");
define("_START_M","1");
define("_START_SZ","");
define("_ADM_EMAIL","derrickwilder48625@outlook.com");
define("_LANG","en");
define("_NOCHMODS","0");
define("_SEO","1");
define("_DHTML_CLICK","1");
define("_DATE_FORMAT","**l**, **F** **j**, **Y**");
define("_TIME_FORMAT","");
define("_SiteName","Company Name");
define("_SiteSlogan","Website Slogan");
define("_SiteTitle","Enter a Number. Find Out Who It Is");
define("_SiteKeywords","");
define("_SiteDescription","");
define("_SiteExtra","");
define("_SiteLogo","data/files/theme/logo-success.svg");
define("_SiteFooter","Copyright (c)2022 {%WebsiteName%}");
define("_MenuLenght","");
define("TitleSeparator","mdash");
define("accessUserPass","");
define("_Site_info_CompanyName","Company Name");
define("_Site_info_Phone","(123) 456-7890");
define("_Site_info_Address","123 Street, Suite 600");
define("_Site_info_City","San Francisco, CA 94107");
define("mailMethod","mail");
define("kopageID","3717-327b4036ee");
define("_SiteFacebook","Facebook");
define("_SiteTwitter","Twitter");
define("_SiteYouTube","YouTube");
define("websiteSSL",1);
define("websiteVersionCheck",1661029653);
define("imagesAutoResize",1);
define("customCookiePage","2_2");

