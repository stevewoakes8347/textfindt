<?php 
define("kopageID","3717-327b4036ee");
define("defaultLanguage","en");
define("_kopageHelpLink_assistant","https://tickets.suresupport.com");
define("kopageLoginOption","NOGOOGLE");
define("_kopageNoLogoMaker","1");